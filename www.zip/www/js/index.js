
$(document).ready(function(){
    $(".lista").append("<ul></ul>").addClass("listt")
});

function ToList(){
    var $('.input') = $input;
    $(".listt").append("<li>"+$input+"</li>");
};

function add(text){
    var clicker = $('#id');
    click.addEventListener('click', function(){
        ToList;
    };
                       
    
    

app.initialize();